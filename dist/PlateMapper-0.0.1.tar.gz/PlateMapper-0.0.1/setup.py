from setuptools import setup

setup(
    name='PlateMapper',
    version='0.0.1',
    packages=['app'],
    url='',
    license='',
    author='Colton J. Garelli',
    author_email='colton.garelli@umassmed.edu',
    description='Plot some plates!',



)
